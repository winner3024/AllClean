﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddEdit
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ShainNum = New System.Windows.Forms.TextBox()
        Me.Num = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NameText = New System.Windows.Forms.TextBox()
        Me.KadouStatus = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.InsertBtn = New System.Windows.Forms.Button()
        Me.ReturnBtn = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'ShainNum
        '
        Me.ShainNum.Font = New System.Drawing.Font("MS UI Gothic", 14.0!)
        Me.ShainNum.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.ShainNum.Location = New System.Drawing.Point(190, 64)
        Me.ShainNum.MaxLength = 5
        Me.ShainNum.Name = "ShainNum"
        Me.ShainNum.Size = New System.Drawing.Size(230, 26)
        Me.ShainNum.TabIndex = 0
        '
        'Num
        '
        Me.Num.AutoSize = True
        Me.Num.Font = New System.Drawing.Font("MS UI Gothic", 12.0!)
        Me.Num.Location = New System.Drawing.Point(98, 69)
        Me.Num.Name = "Num"
        Me.Num.Size = New System.Drawing.Size(72, 16)
        Me.Num.TabIndex = 1
        Me.Num.Text = "社員番号"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("MS UI Gothic", 12.0!)
        Me.Label1.Location = New System.Drawing.Point(98, 135)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(62, 16)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "氏　　名"
        '
        'NameText
        '
        Me.NameText.Font = New System.Drawing.Font("MS UI Gothic", 14.0!)
        Me.NameText.ImeMode = System.Windows.Forms.ImeMode.[On]
        Me.NameText.Location = New System.Drawing.Point(190, 130)
        Me.NameText.MaxLength = 20
        Me.NameText.Name = "NameText"
        Me.NameText.Size = New System.Drawing.Size(230, 26)
        Me.NameText.TabIndex = 3
        '
        'KadouStatus
        '
        Me.KadouStatus.Font = New System.Drawing.Font("MS UI Gothic", 12.0!)
        Me.KadouStatus.FormattingEnabled = True
        Me.KadouStatus.Items.AddRange(New Object() {"", "稼働", "非稼働", "休職"})
        Me.KadouStatus.Location = New System.Drawing.Point(190, 196)
        Me.KadouStatus.Name = "KadouStatus"
        Me.KadouStatus.Size = New System.Drawing.Size(230, 24)
        Me.KadouStatus.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("MS UI Gothic", 12.0!)
        Me.Label2.Location = New System.Drawing.Point(98, 200)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 16)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "稼働状況"
        '
        'InsertBtn
        '
        Me.InsertBtn.Font = New System.Drawing.Font("MS UI Gothic", 12.0!)
        Me.InsertBtn.Location = New System.Drawing.Point(161, 289)
        Me.InsertBtn.Name = "InsertBtn"
        Me.InsertBtn.Size = New System.Drawing.Size(99, 46)
        Me.InsertBtn.TabIndex = 6
        Me.InsertBtn.Text = "登録"
        Me.InsertBtn.UseVisualStyleBackColor = True
        '
        'ReturnBtn
        '
        Me.ReturnBtn.Font = New System.Drawing.Font("MS UI Gothic", 12.0!)
        Me.ReturnBtn.Location = New System.Drawing.Point(321, 289)
        Me.ReturnBtn.Name = "ReturnBtn"
        Me.ReturnBtn.Size = New System.Drawing.Size(99, 46)
        Me.ReturnBtn.TabIndex = 7
        Me.ReturnBtn.Text = "戻る"
        Me.ReturnBtn.UseVisualStyleBackColor = True
        '
        'AddEdit
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(578, 400)
        Me.Controls.Add(Me.ReturnBtn)
        Me.Controls.Add(Me.InsertBtn)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.KadouStatus)
        Me.Controls.Add(Me.NameText)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Num)
        Me.Controls.Add(Me.ShainNum)
        Me.Name = "AddEdit"
        Me.Text = "新規・編集"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ShainNum As TextBox
    Friend WithEvents Num As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents NameText As TextBox
    Friend WithEvents KadouStatus As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents InsertBtn As Button
    Friend WithEvents ReturnBtn As Button
End Class
