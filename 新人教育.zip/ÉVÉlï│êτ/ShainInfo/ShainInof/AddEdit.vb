﻿Public Class AddEdit

    Private Sub AddEdit_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ReturnBtn_Click(sender As Object, e As EventArgs) Handles ReturnBtn.Click
        Me.Close()
    End Sub

    Private Sub InsertBtn_Click(sender As Object, e As EventArgs) Handles InsertBtn.Click

        '入力チェックほしい
        '既存チェックほしい

        'モード別処理
        If Me.InsertBtn.Text = "登録" Then
            '登録
            Call DataAcsess(0)

        Else
            '更新
            Call DataAcsess(1)

            '画面を終了する
            Me.Close()

        End If

    End Sub

    Private Sub DataAcsess(mode As Integer)

        Dim cn As System.Data.OleDb.OleDbConnection
        Dim com As System.Data.OleDb.OleDbCommand
        Dim strSQL As String

        Dim DbPath As String = System.Configuration.ConfigurationManager.AppSettings("DbPath")

        cn = New System.Data.OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;" &
            "DATA SOURCE=" & DbPath & ";" &
            "Persist Security Info = False")

        'モード別でクエリーを切り替え
        If mode = 1 Then
            '更新モード

            strSQL = "UPDATE [USER] SET "
            strSQL = strSQL & " USER_NAME = '" & NameText.Text & "' "
            strSQL = strSQL & ",KADO = '" & KadouStatus.SelectedIndex & "' "
            strSQL = strSQL & " WHERE ID = " & ShainNum.Text

        Else
            '登録モード

            strSQL = "INSERT INTO [USER] (ID,USER_NAME,KADO) VALUES ("
            strSQL = strSQL & ShainNum.Text & ","
            strSQL = strSQL & "'" & NameText.Text & "',"
            strSQL = strSQL & "'" & KadouStatus.SelectedIndex & "')"

        End If

        Try

            cn.Open()

            com = New OleDb.OleDbCommand(strSQL, cn)

            com.ExecuteNonQuery()

            cn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)

            cn.Close()

        End Try

    End Sub

End Class