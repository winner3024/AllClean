﻿Imports Microsoft.VisualBasic.ControlChars

Public Class UserList
    Private Sub UserList_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Call ListPreview()

    End Sub

    Private Sub ReturnBtn_Click(sender As Object, e As EventArgs) Handles ReturnBtn.Click
        Me.Close()
    End Sub

    Private Sub UDGV_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles UDGV.CellClick

        'クリック行のデータを次画面に渡す
        AddEdit.ShainNum.Text = UDGV.Item(0, UDGV.CurrentCell.RowIndex).Value
        AddEdit.NameText.Text = UDGV.Item(1, UDGV.CurrentCell.RowIndex).Value
        AddEdit.KadouStatus.SelectedIndex = UDGV.Item(2, UDGV.CurrentCell.RowIndex).Value

        '更新モードのため、社員番号は編集不可にする
        AddEdit.ShainNum.Enabled = False

        'ボタンのキャプションを「更新」に変更する
        AddEdit.InsertBtn.Text = "更新"

        AddEdit.ShowDialog(Me)

        AddEdit.Dispose()

        '画面のデータを再表示
        Call ListPreview()

    End Sub

    Private Sub ListPreview()

        Dim cn As New System.Data.OleDb.OleDbConnection
        Dim OLEDA As OleDb.OleDbDataAdapter
        Dim OLEDS As DataSet = New DataSet("ユーザ情報")
        Dim strSQL As String

        Dim DbPath As String = System.Configuration.ConfigurationManager.AppSettings("DbPath")

        cn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" &
            "DATA SOURCE=" & DbPath & ";" &
            "Persist Security Info = False"

        strSQL = "SELECT * FROM [USER]"

        OLEDA = New OleDb.OleDbDataAdapter(strSQL, cn)
        Try
            'cn.Open()
            'MessageBox.Show("接続しました。", "通知")

            OLEDA.Fill(OLEDS, "USER")
            Me.UDGV.DataSource = OLEDS.Tables("USER")

            ' 新規行を追加できないようにする
            Me.UDGV.AllowUserToAddRows = False

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

End Class